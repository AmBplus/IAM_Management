namespace Client.Pages;

/// <summary>
/// https://localhost:5000/Index
/// </summary>
public class IndexModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public IndexModel() : base()
	{
	}

	/// <summary>
	/// Handler
	/// </summary>
	public void OnGet()
	{
	}
}
