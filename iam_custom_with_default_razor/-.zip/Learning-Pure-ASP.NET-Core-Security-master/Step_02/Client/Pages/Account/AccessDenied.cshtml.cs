namespace Client.Pages.Account;

/// <summary>
/// https://localhost:5000/Account/AccessDenied
/// </summary>
public class AccessDeniedModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public AccessDeniedModel() : base()
	{
	}

	public void OnGet()
	{
	}
}
