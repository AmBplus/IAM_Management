namespace Client.Pages.Account;

/// <summary>
/// https://localhost:5000/Account/Register
/// </summary>
public class RegisterModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public RegisterModel() : base()
	{
	}

	public void OnGet()
	{
	}
}
