namespace Client.Pages.Account;

/// <summary>
/// https://localhost:5000/Account/Login
/// </summary>
public class LoginModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public LoginModel() : base()
	{
	}

	public void OnGet()
	{
	}
}
