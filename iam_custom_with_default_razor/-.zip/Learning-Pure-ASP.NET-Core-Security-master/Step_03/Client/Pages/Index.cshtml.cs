namespace Client.Pages;

public class IndexModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public IndexModel() : base()
	{
	}

	public void OnGet()
	{
	}
}
