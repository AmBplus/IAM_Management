namespace Client.Pages.Account;

public class RegisterModel :
	Microsoft.AspNetCore.Mvc.RazorPages.PageModel
{
	public RegisterModel() : base()
	{
	}

	public void OnGet()
	{
	}
}
